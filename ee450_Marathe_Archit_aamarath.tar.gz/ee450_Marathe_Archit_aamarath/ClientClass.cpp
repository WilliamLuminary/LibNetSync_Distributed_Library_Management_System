#include "SocketProject.h"
#include <fstream>
#include <utility> 
class Client
{
    public:
    
    void bootup()
    {
        if(setupTCP() == -1)
        {
            printf("ERROR: Client setupTCP failed\n");
            return;
        }
        printf("Client is up and running.\n");
    }

    void connectToServer()
    {
        // referred to from Beejs Socket Programming Guide
        struct addrinfo hints, *server;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        if(getaddrinfo(LOCALHOST, SERVER_MAIN_TCP_PORT, &hints, &server) !=0)
        {
            printf("ERROR:getaddrinfo failed\n");
            return;
        }
        if(connect(fdTCP, server->ai_addr, server->ai_addrlen) != 0)
        {
            freeaddrinfo(server);
            printf("ERROR: Failed to connect to server\n");
            exit(1);
        }
        saveLocalPortNumber();
        freeaddrinfo(server);

    }

    void login()
    {
        bool loggedIn = false;
        admin = false;
        while(!loggedIn)
        {
            char encryptedUsername[BUFFER_LEN];
            char encryptedPassword[BUFFER_LEN];

            printf("Please enter the username: ");
            fgets(username, BUFFER_LEN, stdin);
            username[strcspn(username,"\n")] = 0;
            printf("Please enter the password: ");
            fgets(password, BUFFER_LEN, stdin);
            password[strcspn(password,"\n")] = 0;

            encryptString(username, encryptedUsername);
            encryptString(password, encryptedPassword);
            // printf("%s\n", password);
            // printf("%s\n", encryptedPassword);
            char message[BUFFER_LEN];
            char recvBuffer[BUFFER_LEN];

            char comma = ',';
            // Manually setting the code, sorry
            message[0] = '0';
            message[1] = '\0';
            strcat(message, &comma);
            strcat(message, encryptedUsername);
            strcat(message, &comma);
            strcat(message, encryptedPassword);
            send(fdTCP, message, strlen(message)+1, 0);
            printf("%s sent an authentication request to the Main Server.\n", username);
            recv(fdTCP, recvBuffer, BUFFER_LEN, 0);
            // printf("EXTRA: Recvd Message:%s\n", recvBuffer);


            assert(strlen(recvBuffer) == 1);
            if(recvBuffer[0] == '1')
            {
                printf("%s recieved the result of authentication from Main Server using TCP over port %d. Authentication failed: Username not found.\n", username, localPortNumber);
            }
            else if(recvBuffer[0] == '2')
            {
                printf("%s recieved the result of authentication from Main Server using TCP over port %d. Authentication failed: Password does not match.\n", username, localPortNumber);
            }
            else
            {
                loggedIn = true;
                if(recvBuffer[0] == '3')
                {
                    admin=true;
                }
                printf("%s recieved the result of authentication from Main Server using TCP over port %d. Authentication is successful.\n", username, localPortNumber);

            }



        }
    }

    void requestBook()
    {
        while(true)
        {
            char bookCode[BUFFER_LEN];
            char response[BUFFER_LEN];
            printf("Please enter book code to query: ");
            fgets(bookCode, BUFFER_LEN, stdin);
            bookCode[strcspn(bookCode,"\n")] = 0;
            send(fdTCP, bookCode, strlen(bookCode)+1, 0);

            if(admin)
            {
                printf("Request sent to the Main Server with Admin rights.\n");
            }
            else
            {
                // send(fdTCP, bookCode, strlen(bookCode)+1, 0);
                printf("%s sent the request to the Main Server.\n", username); 
            }
            recv(fdTCP, response, BUFFER_LEN, 0);
            printf("Response recieved from the Main Server on TCP port: %d\n", localPortNumber); 
            // printf("EXTRA: Response: %s\n", response);

            if(response[0] == '0')
            {
                printf("Not able to find the book-code %s in the system.\n", bookCode);
            }
            else
            {
                if(admin)
                {
                    printf("Total number of book %s available = %s\n", bookCode, &response[2]);
                }
                else
                {
                    if(response[2] != '0')
                    {
                        printf("The requested book %s is available in the library.\n", bookCode);
                    }
                    else
                    {
                        printf("The requested book %s is NOT available in the library.\n", bookCode);
                    }
                }
            }

            printf("\n\n--- Start a new query ---\n");


        }
    }

    private:
    int fdTCP;
    int localPortNumber;
    bool admin;
    char username[BUFFER_LEN];
    char password[BUFFER_LEN];

    int setupTCP()
    {
        // referred to from Beejs Socket Programming Guide
        struct addrinfo hints, *result;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        // hints.ai_flags = AI_PASSIVE;
        if(getaddrinfo(LOCALHOST, SERVER_MAIN_TCP_PORT, &hints, &result) !=0)
        {
            printf("ERROR:Client getaddrinfo failed\n");
            return -1;
        }
        fdTCP = socket(result->ai_family, result->ai_socktype, result->ai_protocol);

        freeaddrinfo(result);
        return 0;
    }
    void saveLocalPortNumber()
    {
        // referred to project doc to write this code
        struct sockaddr_in localSocket;
        socklen_t len = sizeof(localSocket);
        if(getsockname(fdTCP, (struct sockaddr*) & localSocket,&len ) == -1)
        {
            return;
        }
        localPortNumber = ntohs(localSocket.sin_port);
        // printf("EXTRA: Client Local Port %d\n", localPortNumber);
    }

    void encryptString(char* original, char* result)
    {
        int ptr=0;
        while(original[ptr] != '\0')
        {
            int asciiCode = (int) original[ptr];
            if('0' <= asciiCode && asciiCode <= '9')
            {
                result[ptr] = (char)((asciiCode - '0' + 5)%10 + '0');
            }
            else if('A' <= asciiCode && asciiCode <= 'Z')
            {
                result[ptr] = (char)((asciiCode - 'A' + 5)%26 + 'A');
            }
            else if('a' <= asciiCode && asciiCode <= 'z')
            {
                result[ptr] = (char)((asciiCode - 'a' + 5)%26 + 'a');
            }
            else
            {
                result[ptr] = (char)asciiCode;
            }
            ptr++;
        }
        result[ptr]='\0';
        return;
    }
};