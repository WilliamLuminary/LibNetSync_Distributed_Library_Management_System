a. Name: Suvi / Archit Abhay Marathe


b. USCID: 7924480773


c. Completed full assignment and extra credit portion.


d. SocketProject.h Header file containing common libraries used across the files and containing constants

   ServerMain.cpp - Class file for the Main server class

   serverM.cpp - Instantiates an object of the main server and calls its methods to perform the function if the main server
   
   ServerDepartment.cpp - Class file for the Department server class

   serverS.cpp - Instantiates a Science server from the department server class

   serverL.cpp - Instantiates a Literature server from the department server class

   serverH.cpp - Instantiates a History server from the department server class

   ClientClass.cpp - Class file for the client

   client.cpp - Instantiates an object of the Client class and calls appropriate methods to run it.

   Makefile - Provides shortcut commands to compile the project


e. client to serverM:
    - username and password:  a zero, followed by encrypted username and then encrypted password, concatenated and delimited by a comma.
    - bookcodes: as is

   serverM to server[S,L,H]
    - bookCode: First char is 1 if client is admin and 0 otherwise, followed by a comma and then the bookcode

   server[S,L,H] to serverM
    - book availibility: 0 if the book is not present. Else 1 followed by a comma followed by the count of the book

   serverM to client:
    - authentication response: 1 digit response code
                              -1: Username does not exist
                              -2: Password incorrect
                              -3: Login successful with admin rights
                              -4: Login successful
    - book status: 0 if book does not exist. Else 1 followed by a comma followed by the count of the book


g. None


h. I referred to code from the Beej's Socket programming guide. Specifically, the parts relating to getaddrinfo. I also used the code given in the project doc on page 15 to get the locally-bound port number. All else is code written by me.
