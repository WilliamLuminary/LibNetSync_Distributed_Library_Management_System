#include "SocketProject.h"
#include "ServerDepartment.cpp"


int main() {
  ServerDepartment serverS('H');
  serverS.bootup();
  serverS.startListen();
  return 0;
}