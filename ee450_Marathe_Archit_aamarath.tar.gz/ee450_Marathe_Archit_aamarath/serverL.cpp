#include "SocketProject.h"
#include "ServerDepartment.cpp"


int main() {
  ServerDepartment serverS('L');
  serverS.bootup();
  serverS.startListen();
  return 0;
}