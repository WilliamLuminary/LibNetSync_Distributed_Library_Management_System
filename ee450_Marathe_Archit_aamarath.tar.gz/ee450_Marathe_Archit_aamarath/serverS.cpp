#include "SocketProject.h"
#include "ServerDepartment.cpp"


int main() {
  ServerDepartment serverS('S');
  serverS.bootup();
  serverS.startListen();
  return 0;
}