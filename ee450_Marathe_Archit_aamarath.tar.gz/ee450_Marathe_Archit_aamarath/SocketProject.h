#ifndef SOCKET_PROJECT
#define SOCKET_PROJECT

#include <stdio.h>  // Include standard I/O header
#include <stdlib.h> // Include standard library header
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netdb.h>
#include <string>
#include <assert.h>

#define LOGGING 1
const char LOCALHOST[] = "127.0.0.1";
const char SERVER_S_UDP_PORT[]    = "41773";
const char SERVER_L_UDP_PORT[]    = "42773";
const char SERVER_H_UDP_PORT[]    = "43773";
const char SERVER_MAIN_UDP_PORT[] = "44773";
const char SERVER_MAIN_TCP_PORT[] = "45773";

const int BUFFER_LEN = 200;
const std::string ADMIN_USERNAME= "firns"; // rethink using string for this

#endif
