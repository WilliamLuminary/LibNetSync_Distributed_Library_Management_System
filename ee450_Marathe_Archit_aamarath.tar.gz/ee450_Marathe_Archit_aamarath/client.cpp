#include "SocketProject.h"
#include "ClientClass.cpp"

int main() {
  Client client;
  client.bootup();
  client.connectToServer();
  client.login();
  client.requestBook();
  return 0;
}