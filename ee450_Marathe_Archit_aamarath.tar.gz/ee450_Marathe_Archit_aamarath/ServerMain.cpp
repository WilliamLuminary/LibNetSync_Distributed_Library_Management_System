#include "SocketProject.h"
#include <map>
#include <fstream>
#include <utility> 
class ServerMain
{
    public:

    ServerMain()
    {
        adminAccess = false;
    }
    
    void bootup()
    {
        if(setupUDP() == -1)
        {
            printf("ERROR: setupUDP failed\n");
            return;
        }
        if(setupTCP() == -1)
        {
            printf("ERROR: setupTCP failed\n");
            return;
        }
        printf("Main server is up and running.\n");
    }

    void loadMembers()
    {
        std::ifstream membersList("member.txt");
        std::string currentLine;
        while(std::getline(membersList, currentLine))
        {
            if(currentLine[currentLine.size() - 1] == '\r')
                currentLine.erase(currentLine.size() - 1);
            int posComma = currentLine.find(',');
            std::string username = currentLine.substr(0, posComma);
            std::string password = currentLine.substr(posComma+2);
            members.insert(std::make_pair(username,password));
            // for(int i=0;i<(int) password.length();i++)
            // {
            //     printf("%d ",(int)password[i]);
            // }
            // printf("\n");

        }
        printf("Main Server loaded the member list.\n");
        
        return;
    }

    void startListen()
    {
        listen(fdTCP,10);
    }

    void process()
    {
        struct sockaddr clientAddr;
        socklen_t len = sizeof(clientAddr);
        while(1)
        {
            fdChildTCP = accept(fdTCP, &clientAddr, &len);
            saveChildPortNumber();
            if(getUsernamePassword() == 0)
                getBookRequest();
        }
    }
    private:
    int fdTCP;
    int fdUDP;
    int fdChildTCP;
    int childPortNumber;
    std::map<std::string, std::string>  members;
    bool adminAccess;
    
    int setupUDP()
    {
        // referred to from Beejs Socket Programming Guide
        struct addrinfo hints, *result;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_DGRAM;
        // hints.ai_flags = AI_PASSIVE;
        if(getaddrinfo(LOCALHOST, SERVER_MAIN_UDP_PORT, &hints, &result) !=0)
        {
            printf("ERROR:getaddrinfo failed\n");
            return -1;
        }
        fdUDP = socket(result->ai_family, result->ai_socktype, result->ai_protocol);

        bind(fdUDP, result->ai_addr, result->ai_addrlen);
        freeaddrinfo(result);
        // printf("EXTRA: Main Server UDP is up on Port %s\n", SERVER_MAIN_UDP_PORT);
        return 0;
    }

    int setupTCP()
    {
        // referred to from Beejs Socket Programming Guide
        struct addrinfo hints, *result;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        // hints.ai_flags = AI_PASSIVE;
        if(getaddrinfo(LOCALHOST, SERVER_MAIN_TCP_PORT, &hints, &result) !=0)
        {
            printf("ERROR:getaddrinfo failed\n");
            return -1;
        }
        fdTCP = socket(result->ai_family, result->ai_socktype, result->ai_protocol);

        bind(fdTCP, result->ai_addr, result->ai_addrlen);
        freeaddrinfo(result);
        // printf("EXTRA: Main server TCP is up on Port %s\n", SERVER_MAIN_TCP_PORT);
        return 0;

    }

    void saveChildPortNumber()
    {
        struct sockaddr_in localSocket;
        socklen_t len = sizeof(localSocket);
        if(getsockname(fdChildTCP, (struct sockaddr*) & localSocket,&len ) == -1)
        {
            return;
        }
        childPortNumber = ntohs(localSocket.sin_port);
        // printf("EXTRA: Client Local Port %d\n", localPortNumber);
    }


    int getUsernamePassword()
    {
        bool authenticated = false;
        char buffer[BUFFER_LEN];
        std::string recvdMessage;
        int pos;
        while(!authenticated)
        {
            buffer[0]=0;
            recv(fdChildTCP,buffer,BUFFER_LEN,0);
            if(strlen(buffer) == 0)
            {
                return -1;
            }
            printf("Main server received the username and password from the client using TCP over port %d\n", childPortNumber);

            recvdMessage = std::string(buffer);
            // printf("Recieved Message:%s\n", recvdMessage.c_str());
            
            pos = recvdMessage.find(',');
            std::string code = recvdMessage.substr(0,pos);

            recvdMessage = recvdMessage.substr(pos+1);
            pos = recvdMessage.find(',');
            std::string username = recvdMessage.substr(0,pos);

            std::string password = recvdMessage.substr(pos+1);
            // printf("%s\n", password.c_str());


            std::map<std::string, std::string>::iterator itr = members.find(username);
            std::string sendMessage;
            if(itr == members.end())
            {
                //username not found
                printf("%s is not registered. Send a reply to the client.\n", username.c_str());
                sendMessage = "1";
                
            }
            else if(password.compare(itr->second)!=0)
            {
                //Incorrect password
                // printf("Expected Len %d\n",(int) itr->second.length());
                // printf("Recieved Len %d\n",(int) password.length());
                // printf("Expected %s\n", itr->second.c_str());
                // printf("Received %s\n", password.c_str());
                printf("Password %s does not match the username. Send a reply to the client.\n", password.c_str());
                sendMessage = "2";
            }
            else
            {
                //Logged in!
                authenticated = true;
                printf("Password %s matches the username. Send a reply to the client.\n", password.c_str());

                // ADMIN access
                if(username == ADMIN_USERNAME)
                {
                    sendMessage = "3";
                    adminAccess = true;
                }
                else
                {
                    sendMessage = "4";
                }


            }
            strncpy(buffer, sendMessage.c_str(), BUFFER_LEN);
            send(fdChildTCP, buffer, strlen(buffer)+1, 0);

        }
        return 0;
    }

    void getBookRequest()
    {
        char bookCode[BUFFER_LEN];
        char sendToClient[BUFFER_LEN];
        struct sockaddr_storage senderAddr;
        socklen_t addrLen = sizeof senderAddr;

        while(true)
        {
            
            recv(fdChildTCP, bookCode, BUFFER_LEN, 0);
            printf("Main server received the book request from client using TCP over port %d\n", childPortNumber);

            if(!(bookCode[0] == 'S' || bookCode[0] == 'L'|| bookCode[0] == 'H'))
            {
                printf("Did not find %s in book code list.\n", bookCode);
                sendToClient[0] = '0';
                sendToClient[1] = 0;
            }
            else
            {
                char sendBufferUDP[BUFFER_LEN];

                if(adminAccess) sendBufferUDP[0] = '1';
                else sendBufferUDP[0] = '0';

                sendBufferUDP[1] = ',';
                sendBufferUDP[2] = 0;
                strncat(sendBufferUDP, bookCode, BUFFER_LEN);

                const char *RECIEVER_PORT;
                if(bookCode[0] == 'S')      RECIEVER_PORT = SERVER_S_UDP_PORT;
                else if(bookCode[0] == 'L') RECIEVER_PORT = SERVER_L_UDP_PORT;
                else                        RECIEVER_PORT = SERVER_H_UDP_PORT;

                // referred to from Beejs Socket Programming Guide
                struct addrinfo hints, *destInfo;
                memset(&hints, 0, sizeof hints);
                hints.ai_family = AF_INET;
                hints.ai_socktype = SOCK_DGRAM;
                int rv;
                if(rv = getaddrinfo(LOCALHOST, RECIEVER_PORT, &hints, &destInfo) != 0)
                {
                    printf("ERROR:getaddrinfo failed\n");
                    printf("getaddrinfo: %s\n", gai_strerror(rv));
                    return;
                }
                printf("Found %s located at Server %c. Send to Server %c.\n", bookCode, bookCode[0], bookCode[0]);
                sendto(fdUDP, sendBufferUDP, strlen(sendBufferUDP)+1, 0, destInfo->ai_addr, destInfo->ai_addrlen);


                char recvMessage[BUFFER_LEN];
                recvfrom(fdUDP, recvMessage, BUFFER_LEN, 0, (struct sockaddr*) &senderAddr,  &addrLen);
                // printf("EXTRA: Recvd message: %s\n", recvMessage);
                if(recvMessage[0] == '0')
                {
                    printf("Did not find %s in book code list.\n", bookCode);
                    sendToClient[0]='0';
                    sendToClient[1]=0;
                }
                else
                {
                    strncpy(sendToClient, recvMessage, BUFFER_LEN);
                    printf("Main Server received from server %c the book status result using UDP over port %s: Number of books %s available is: %s.\n", bookCode[0], SERVER_MAIN_UDP_PORT, bookCode, &recvMessage[2]);

                }

            }
            // printf("EXTRA: Sending message: %s, with length %d.\n", sendToClient, (int)strlen(sendToClient));
            send(fdChildTCP, sendToClient, strlen(sendToClient)+1, 0);
            printf("Main Server sent the book status to the client.\n");
        }

        return;


    }
    

};