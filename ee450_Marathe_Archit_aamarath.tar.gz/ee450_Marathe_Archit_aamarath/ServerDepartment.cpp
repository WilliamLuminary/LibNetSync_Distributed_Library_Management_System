#include "SocketProject.h"
#include <map>
#include <fstream>
class ServerDepartment
{
    public:
    	ServerDepartment(char serverCode)
    	{
    		this->serverCode=serverCode;
    		if(this->serverCode == 'S')
    		{
    			portNumberUDP = SERVER_S_UDP_PORT;
    			strncpy(bookListFile,  "science.txt", BUFFER_LEN);

    		}
    		else if(this->serverCode == 'L')
    		{
    			portNumberUDP = SERVER_L_UDP_PORT;
    			strncpy(bookListFile,  "literature.txt", BUFFER_LEN);
    		}
    		else if(this->serverCode == 'H')
    		{
    			portNumberUDP = SERVER_H_UDP_PORT;
    			strncpy(bookListFile,  "history.txt", BUFFER_LEN);
    		}
    	}

    	void bootup()
    	{
    		if(setupUDP() == -1)
	        {
	            printf("ERROR: setupUDP failed\n");
	            return;
	        }
	        loadBooks();

        	printf("Server %c is up and running using UDP on port %s.\n", serverCode, portNumberUDP);
    	}

    	void startListen()
    	{
    		struct sockaddr_storage senderAddr;
    		char recvBuffer[BUFFER_LEN];
    		char sendBuffer[BUFFER_LEN];

    		socklen_t addrLen = sizeof senderAddr;
    		while(1)
    		{
    			bool adminAccess = false;
    			recvfrom(fdUDP, recvBuffer, BUFFER_LEN, 0, (struct sockaddr*) &senderAddr,  &addrLen);
	    		// printf("EXTRA: Server %c recieved message: %s\n", serverCode, recvBuffer);

    			std::string bookCode(&recvBuffer[2]);
                adminAccess = (recvBuffer[0] == '1');
                if(adminAccess)
                {
                    printf("Server %c received an inventory status request for code %s.\n", serverCode, bookCode.c_str());
                }
                else
                {
                    printf("Server %c recieved %s code from the Main Server.\n", serverCode, bookCode.c_str());
                }

	    		std::map<std::string,int>::iterator bookEntry = books.find(bookCode);
	    		if(bookEntry == books.end())
	    		{
		        	// printf("EXTRA: Book %s not found at Server %c\n", bookCode.c_str(), serverCode);

		        	sendBuffer[0]='0';
		        	sendBuffer[1]='\0';
		        	// sendto(fdUDP, sendBuffer, strlen(sendBuffer)+1, 0, (struct sockaddr*) &senderAddr,  addrLen);
	    		}
                else
                {
                    int bookCount = bookEntry->second;
                    sendBuffer[0] = '1';
                    sendBuffer[1] = ',';
                    sendBuffer[2] = 0;
                    sprintf(&sendBuffer[2],"%d",bookCount);
                    // Decrement count if customer request and count>0
                    if(!adminAccess && bookCount > 0)
                    {
                        
                        bookEntry->second = bookCount-1;
                    }
                }
                sendto(fdUDP, sendBuffer, strlen(sendBuffer)+1, 0, (struct sockaddr*) &senderAddr,  addrLen);
                if(adminAccess)
                {
                    printf("Server %c finished sending the inventory status to the Main server using UDP on port %s.\n", serverCode, portNumberUDP);
                }
                else
                {
                    printf("Server %c finished sending the availability status of code %s to the Main Server using UDP on port %s.\n", serverCode, bookCode.c_str(), portNumberUDP);
                }

    		}
    		

    	}

    private:
    	char serverCode;
    	int fdUDP;
    	const char *portNumberUDP;
    	char bookListFile[BUFFER_LEN];
    	std::map<std::string, int>  books;

    	void loadBooks()
    	{
    		std::ifstream bookList(bookListFile);
        	std::string currentLine;
	        while(std::getline(bookList, currentLine))
	        {
	            if(currentLine[currentLine.size() - 1] == '\r')
	                currentLine.erase(currentLine.size() - 1);
	            int posComma = currentLine.find(',');
	            std::string bookName = currentLine.substr(0, posComma);
	            int bookCount = atoi((currentLine.substr(posComma+2)).c_str());
	            books.insert(std::make_pair(bookName,bookCount));

	        }
	        return;
    	}

    	int setupUDP()
    	{
            // referred to from Beejs Socket Programming Guide
    		struct addrinfo hints, *result;
	        memset(&hints, 0, sizeof hints);
	        hints.ai_family = AF_INET;
	        hints.ai_socktype = SOCK_DGRAM;
	        // hints.ai_flags = AI_PASSIVE;
	        if(getaddrinfo(LOCALHOST, portNumberUDP, &hints, &result) !=0)
	        {
	            printf("ERROR:getaddrinfo failed\n");
	            return -1;
	        }
	        fdUDP = socket(result->ai_family, result->ai_socktype, result->ai_protocol);

	        bind(fdUDP, result->ai_addr, result->ai_addrlen);
	        freeaddrinfo(result);
	        // printf("EXTRA: Server %c UDP is up on Port %s\n", serverCode, portNumberUDP);
	        return 0;
    	}

};