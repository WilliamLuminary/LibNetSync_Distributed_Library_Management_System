#include "SocketProject.h"
#include "ServerMain.cpp"


int main() {
  ServerMain serverM;
  serverM.bootup();
  serverM.loadMembers();
  serverM.startListen();
  serverM.process();
  return 0;
}